import json, logging
from contextvars import ContextVar
from datetime import datetime

current_scan_id = ContextVar('scan_id', default='')

class JSONFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "time": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "msg": record.getMessage(),
            "scan_id": current_scan_id.get()
        })
