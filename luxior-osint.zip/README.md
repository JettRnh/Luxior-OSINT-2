# Luxior OSINT V2.1
Owner: Jet
GitHub: JettRnh
TikTok: @jettinibos_
